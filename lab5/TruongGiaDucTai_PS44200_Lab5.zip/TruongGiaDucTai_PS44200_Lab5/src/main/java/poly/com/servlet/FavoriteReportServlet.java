package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.FavoriteDAOImpl;
import poly.com.dao.FavoriteIDAO;
import poly.com.entity.Favorite; 

import java.io.IOException;
import java.util.List;

@WebServlet("/favorite-report")
public class FavoriteReportServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private FavoriteIDAO favoriteDAO;

    public FavoriteReportServlet() {
        super();
        favoriteDAO = new FavoriteDAOImpl();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        try {
            // 1. Truy vấn tất cả Favorite bằng phương thức mới đã xử lý JOIN FETCH
            List<Favorite> favorites = favoriteDAO.findAllWithDetails();

            // 2. Đặt dữ liệu vào Request Scope
            request.setAttribute("favorites", favorites);
            
            // Chuyển hướng sang trang JSP mới (report.jsp)
            request.getRequestDispatcher("/views/favorite-report.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("error", "Lỗi tạo báo cáo: " + e.getMessage());
            request.getRequestDispatcher("/views/error.jsp").forward(request, response);
        }
    }
}