package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.UserDAOImpl;
import poly.com.dao.UserIDAO;
import poly.com.dao.FavoriteDAOImpl;
import poly.com.dao.FavoriteIDAO;
import poly.com.entity.User;
import poly.com.entity.Favorite;

import java.io.IOException;
import java.util.List;

@WebServlet("/favorites")
public class FavoriteServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private UserIDAO userDAO;
    private FavoriteIDAO favoriteDAO;

    public FavoriteServlet() {
        super();
        userDAO = new UserDAOImpl();
        favoriteDAO = new FavoriteDAOImpl();
    }

    @Override
    protected void service(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("UTF-8");
        response.setContentType("text/html;charset=UTF-8");

        String searchInput = request.getParameter("searchInput");
        String type = request.getParameter("type"); // "user" hoặc "video"

        request.setAttribute("searchTerm", searchInput);

        if (searchInput != null && !searchInput.trim().isEmpty()) {
            if ("user".equals(type)) {
                handleUserSearch(request, response, searchInput.trim());
            } else if ("video".equals(type)) {
                handleVideoSearch(request, response, searchInput.trim());
            }
        } else {
            request.getRequestDispatcher("/views/favorites.jsp").forward(request, response);
        }
    }


    private void handleUserSearch(HttpServletRequest request, HttpServletResponse response, String term)
            throws ServletException, IOException {
        try {
            User user = userDAO.findUserBySearchTerm(term);
            if (user != null) {
                List<Favorite> favorites = user.getFavorites();
                request.setAttribute("userFullname", user.getFullname());
                request.setAttribute("favorites", favorites);
                request.setAttribute("messageUser", "Tìm thấy người dùng: " + user.getFullname());
            } else {
                request.setAttribute("errorUser", "Không tìm thấy người dùng: " + term);
            }
        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorUser", "Lỗi truy vấn dữ liệu: " + e.getMessage());
        }
        request.getRequestDispatcher("/views/favorites.jsp").forward(request, response);
    }

    private void handleVideoSearch(HttpServletRequest request, HttpServletResponse response, String videoId)
            throws ServletException, IOException {
        try {
            List<User> users = favoriteDAO.findUsersByVideoId(videoId);
            request.setAttribute("users", users);
            request.setAttribute("videoId", videoId);

            if (users.isEmpty()) {
                request.setAttribute("messageVideo", "Không có user nào yêu thích video này.");
            } else {
                request.setAttribute("messageVideo", "Danh sách User đã yêu thích video ID: " + videoId);
            }

        } catch (Exception e) {
            e.printStackTrace();
            request.setAttribute("errorVideo", "Lỗi truy vấn: " + e.getMessage());
        }
        request.getRequestDispatcher("/views/favorites.jsp").forward(request, response);
    }

}
