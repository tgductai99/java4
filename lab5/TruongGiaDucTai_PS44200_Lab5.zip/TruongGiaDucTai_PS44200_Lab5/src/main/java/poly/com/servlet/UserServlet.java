package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.UserDAOImpl;
import poly.com.dao.UserIDAO;
import poly.com.entity.User;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet({ "/user/index", "/user/create", "/user/update", "/user/delete", "/user/reset", "/user/edit/*",
		"/user/delete/*", "/user/search-domain", "/user/search-email", "/user/page" })
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserIDAO dao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
		dao = new UserDAOImpl();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		User user = null;

		String servletPath = request.getServletPath(); // /user/index, /user/page, /user/edit, ...

		if (servletPath.equals("/user/delete")) {
			String id = request.getParameter("id");
			if (id != null && !id.isEmpty()) {
				dao.delete(id);
				request.setAttribute("message", "Delete success!");
			}
			user = new User();
			request.setAttribute("user", user);

		} else if (servletPath.equals("/user/edit")) {
			String id = request.getParameter("id");
			if (id != null && !id.isEmpty()) {
				user = dao.findById(id);
			}
			request.setAttribute("user", user);

		}

		// Phân trang
		int pageSize = 5;
		int pageNumber = 0; // mặc định trang 1
		String p = request.getParameter("p");
		if (p != null) {
			try {
				pageNumber = Integer.parseInt(p) - 1;
				if (pageNumber < 0)
					pageNumber = 0;
			} catch (Exception e) {
				pageNumber = 0;
			}
		}
		showPage(request, response, pageNumber, pageSize);

		// Nếu không có user edit/delete thì tạo user rỗng
		if (user == null)
			user = new User();
		request.setAttribute("user", user);

		request.getRequestDispatcher("/views/user.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String url = request.getRequestURL().toString();

		if (url.contains("/user/create")) {
			create(request, response);
		} else if (url.contains("/user/update")) {
			update(request, response);
		} else if (url.contains("/user/delete")) {
			delete(request, response);
		} else if (url.contains("/user/reset")) {
			request.setAttribute("user", new User());
			findAll(request, response);
		} else if (url.contains("/user/search-domain")) {
			searchByDomain(request, response);
		} else if (url.contains("/user/search-email")) {
			searchByEmail(request, response);
		}

		request.getRequestDispatcher("/views/user.jsp").forward(request, response);
	}

	private void create(HttpServletRequest request, HttpServletResponse response) {
		try {
			User user = new User();
			BeanUtils.populate(user, request.getParameterMap());
			if (dao.findById(user.getId()) != null) {
				request.setAttribute("error", "ID đã tồn tại, vui lòng nhập ID khác!");
			} else {
				dao.create(user);
				request.setAttribute("message", "Create success!");
			}
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	private void update(HttpServletRequest request, HttpServletResponse response) {
		try {
			User user = new User();
			BeanUtils.populate(user, request.getParameterMap());
			dao.update(user);
			request.setAttribute("message", "Update success!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) {
		try {
			User user = new User();
			BeanUtils.populate(user, request.getParameterMap());
			if (user.getId() != null) {
				dao.delete(user.getId());
			}
			request.setAttribute("message", "Delete success!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	private void findAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<User> list = dao.findAll();
			request.setAttribute("users", list);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	private void searchByDomain(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<User> listByDomain = dao.findByEmailDomain("fpt.edu.vn");
			List<User> result = new ArrayList<>();

			for (User u : listByDomain) {
				if (u != null && !u.isAdmin()) {
					result.add(u);
				}
			}

			request.setAttribute("users", result);
			request.setAttribute("message",
					"Kết quả Bài 3: Những user có email kết thúc @fpt.edu.vn và không phải admin");

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Lỗi khi tìm: " + e.getMessage());
		}
	}

	private void searchByEmail(HttpServletRequest request, HttpServletResponse response) {
		try {
			String email = request.getParameter("email");
			List<User> result = dao.findByEmail(email);

			request.setAttribute("users", result);
			request.setAttribute("message", "Kết quả tìm kiếm cho email: " + email);

		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Lỗi khi tìm: " + e.getMessage());
		}
	}

	private void showPage(HttpServletRequest request, HttpServletResponse response, int pageNumber, int pageSize) {
		try {
			List<User> list = dao.findUsersInPage(pageNumber, pageSize);
			request.setAttribute("users", list);

			// Tính tổng số trang
			int totalUsers = dao.findAll().size(); // hoặc dao.countAll() nếu có
			int totalPages = (int) Math.ceil((double) totalUsers / pageSize);
			request.setAttribute("totalPages", totalPages);

			// Trang hiện tại
			request.setAttribute("currentPage", pageNumber + 1);

			request.setAttribute("message", "Hiển thị trang " + (pageNumber + 1));
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Lỗi khi truy vấn trang: " + e.getMessage());
		}
	}

}
