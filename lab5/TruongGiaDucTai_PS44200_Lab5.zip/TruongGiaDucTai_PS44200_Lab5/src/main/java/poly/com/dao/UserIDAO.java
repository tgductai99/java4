package poly.com.dao;

import java.util.List;
import poly.com.entity.User;

public interface UserIDAO extends ICRUD<User, String> {
	List<User> findByEmailDomain(String domain);

	List<User> findAdmins();

	List<User> findUsersInPage(int pageNumber, int pageSize);
	
	List<User> findByEmail(String email);
	
	User findUserBySearchTerm(String term);
	
	User findByIdOrEmail(String term);
}
