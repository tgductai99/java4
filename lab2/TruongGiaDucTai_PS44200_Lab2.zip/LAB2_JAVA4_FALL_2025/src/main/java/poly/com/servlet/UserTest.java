package poly.com.servlet;

import poly.com.servlet.UserManager;

public class UserTest {

	public static void main(String[] args)
	{
		UserManager manager = new UserManager();
		
		// --- Test BÀI 2: CRUD ---
//		 manager.create(); 
		// manager.update();
		 manager.findById("U01");
		// manager.deleteById("U01");
		
		manager.findAll(); 

		// --- Test BÀI 3: Truy vấn có điều kiện ---
		manager.findUserByEmailAndRole();

		// --- Test BÀI 4: Truy vấn phân trang ---
		int pageNumber = 2; 
		int pageSize = 5;
		manager.findUsersInPage(pageNumber, pageSize);
		
		// Đóng tài nguyên sau khi hoàn thành
		manager.close();
	}
}
