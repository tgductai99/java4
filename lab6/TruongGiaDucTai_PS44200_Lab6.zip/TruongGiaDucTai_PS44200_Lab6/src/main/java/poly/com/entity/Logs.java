package poly.com.entity;

import java.util.Date;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Logs")
public class Logs {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "Url", length = 500)
    private String url;

    @Temporal(TemporalType.TIMESTAMP)
    @Column(name = "AccessTime")
    private Date time;

    @Column(name = "Username", length = 50)
    private String username;
    
    // (1) Constructors (Không tham số và đầy đủ tham số)

    // (2) Getters và Setters
    // ... (Viết code Getters/Setters cho 4 trường trên)
}