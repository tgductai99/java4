package poly.com.filter;

import java.io.IOException;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import poly.com.filter.HttpFilter; 
import poly.com.entity.User; 

@WebFilter(filterName = "AuthFilter", urlPatterns = {"/*"})
public class AuthFilter implements HttpFilter { 

    private static final String USER_SESSION_KEY = "userLogin";
    private static final String SECURITY_URI_KEY = "securityUri"; 

    // Các URI công khai (Không cần đăng nhập)
    private static final String[] PUBLIC_URIS = {
        "/home",       // Trang Chủ
        "/video/search", // Tìm Kiếm Video
        "/auth",       // Login, Logout, Forgot Password, Register
        "/error"
    };
    
    // Các URI cần quyền Admin (Ngoại trừ /admin mặc định đã được check)
    private static final String[] ADMIN_URIS = {
        "/user/index"
    };

	@Override
	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
			throws IOException, ServletException {
		
        String uri = req.getRequestURI();
        HttpSession session = req.getSession(false);
        User user = (session != null) ? (User) session.getAttribute(USER_SESSION_KEY) : null;
        
        boolean loggedIn = (user != null);
        
        // 1. Kiểm tra URI có phải là công khai hay không
        // ✅ SỬA: Truyền 'req' vào hàm
        boolean isPublic = isPublicUri(req, uri);
        
        // 2. Kiểm tra có cần quyền Admin hay không
        // Bao gồm cả /admin (mặc định) và các URI trong ADMIN_URIS
        // ✅ SỬA: Truyền 'req' vào hàm
        boolean isAdminRequired = uri.contains("/admin") || isAdminUri(req, uri);

        if (isAdminRequired && (user == null || !user.isAdmin())) {
            // Trường hợp 1: Cần Admin nhưng User không đăng nhập hoặc không phải Admin
            handleSecurityViolation(req, resp, "Bạn cần quyền Admin để truy cập!", true);
            return;
        }

        if (!isPublic && !loggedIn) {
            // Trường hợp 2: URI không công khai VÀ User chưa đăng nhập
            handleSecurityViolation(req, resp, "Bạn cần đăng nhập để truy cập!", false);
            return;
        }

        // Nếu mọi thứ hợp lệ hoặc là URI công khai
		chain.doFilter(req, resp);
	}

    /**
     * Kiểm tra xem URI có phải là URI công khai (PUBLIC_URIS) hay không
     * ✅ SỬA: Thêm tham số HttpServletRequest req
     */
    private boolean isPublicUri(HttpServletRequest req, String uri) {
        // Loại bỏ Context Path để kiểm tra chính xác hơn, ví dụ: /Lab/auth/login -> /auth/login
        String path = uri.substring(req.getContextPath().length()); 
        
        for (String publicUri : PUBLIC_URIS) {
            if (path.contains(publicUri)) {
                return true;
            }
        }
        // Cho phép truy cập các file tĩnh (CSS, JS, hình ảnh)
        if (uri.endsWith(".css") || uri.endsWith(".js") || uri.endsWith(".png") || uri.endsWith(".jpg") || uri.endsWith(".woff2")) {
            return true;
        }
        return false;
    }
    
    /**
     * Kiểm tra xem URI có phải là URI yêu cầu Admin (ADMIN_URIS) hay không
     * ✅ SỬA: Thêm tham số HttpServletRequest req
     */
     private boolean isAdminUri(HttpServletRequest req, String uri) {
         String path = uri.substring(req.getContextPath().length());
         for (String adminUri : ADMIN_URIS) {
             if (path.contains(adminUri)) {
                 return true;
             }
         }
         return false;
     }


    private void handleSecurityViolation(HttpServletRequest req, HttpServletResponse resp, String errorMessage, boolean isAdminViolation)
            throws IOException, ServletException {
        
        HttpSession session = req.getSession(true); 
        
        session.setAttribute("error", errorMessage);
        
        // Lưu URI bị chặn để chuyển hướng lại sau khi đăng nhập thành công
        if (!isAdminViolation) {
            session.setAttribute(SECURITY_URI_KEY, req.getRequestURI());
        }
        
        // Chuyển hướng đến trang đăng nhập
        resp.sendRedirect(req.getContextPath() + "/auth/login");
    }
}