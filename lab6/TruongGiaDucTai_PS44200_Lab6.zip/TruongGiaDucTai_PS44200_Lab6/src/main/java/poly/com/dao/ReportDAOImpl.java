package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.Report;

public class ReportDAOImpl extends AbstractDAO<Report, Integer> implements ReportIDAO {

    public ReportDAOImpl() {
        super(Report.class);
    }

    @Override
    public List<Report> findReportsByGroup(String groupName) {
        return executeQuery(em -> {
            // Lưu ý: Tên cột là Groupp
            String jpql = "SELECT r FROM Report r WHERE r.group = :groupName ORDER BY r.date DESC"; 
            TypedQuery<Report> query = em.createQuery(jpql, Report.class);
            query.setParameter("groupName", groupName);
            return query.getResultList();
        });
    }

    @Override
    public List<Report> findReportsByYear(int year) {
        return executeQuery(em -> {
            // Sử dụng hàm YEAR() của HQL/JPQL (có thể không hoạt động trên mọi DB)
            // Phương pháp tốt hơn là sử dụng hàm EXTRACT(YEAR FROM r.date) hoặc BETWEEN
            // Tôi sẽ dùng hàm YEAR() vì nó phổ biến trong các hệ thống đơn giản:
            String jpql = "SELECT r FROM Report r WHERE YEAR(r.date) = :year ORDER BY r.date DESC";
            TypedQuery<Report> query = em.createQuery(jpql, Report.class);
            query.setParameter("year", year);
            return query.getResultList();
        });
    }

}