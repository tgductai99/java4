package poly.com.dao;
import poly.com.entity.Logs;

public class LogsDAOImpl extends AbstractDAO<Logs, Long> implements LogsIDAO {
    public LogsDAOImpl() {
        super(Logs.class);
    }
}