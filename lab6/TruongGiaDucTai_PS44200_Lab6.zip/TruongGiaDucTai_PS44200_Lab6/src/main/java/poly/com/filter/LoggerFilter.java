package poly.com.filter; 

import java.io.IOException;
import java.util.Date;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import poly.com.filter.HttpFilter; // Interface HttpFilter tùy chỉnh của bạn
import poly.com.entity.User; // Giả định Entity User

@WebFilter(filterName = "LoggerFilter", urlPatterns = {"/*"})
public class LoggerFilter implements HttpFilter { 

    private static final String USER_SESSION_KEY = "userLogin"; // Key Session từ LoginServlet

    @Override
	public void doFilter(HttpServletRequest req, HttpServletResponse resp, FilterChain chain)
			throws IOException, ServletException {

        // Lấy session hiện tại (không tạo mới)
        HttpSession session = req.getSession(false); 
        String uri = req.getRequestURI();
        
        // Lấy thông tin User TRƯỚC khi Servlet xử lý
        User userBefore = (session != null) ? (User) session.getAttribute(USER_SESSION_KEY) : null;
        String usernameBefore = (userBefore != null) ? userBefore.getId() : "guest"; 
        
        // ==========================================================
        // 1. GHI LOG TRUY CẬP (Nếu người dùng đã đăng nhập)
        // ==========================================================
        if (!"guest".equals(usernameBefore)) { 
            System.out.println("[ACCESS LOG] URI: " + uri + 
                               " | User: " + usernameBefore + 
                               " | Time: " + new Date());
        }
        
		chain.doFilter(req, resp);
        
        // ==========================================================
        // 2. GHI LOG ĐĂNG NHẬP THÀNH CÔNG (Sau khi Servlet xử lý)
        // ==========================================================
        if (session != null) {
            try {
                // ✅ XỬ LÝ LỖI: Bọc trong try-catch để session bị hủy (khi logout) không gây lỗi 500
                User userAfter = (User) session.getAttribute(USER_SESSION_KEY);
                
                // Logic: Có User mới VÀ User trước đó là guest HOẶC ID đã thay đổi
                if (userAfter != null && (userBefore == null || !userBefore.getId().equals(userAfter.getId()))) {
                    System.out.println("[LOGIN SUCCESS] User logged in: " + userAfter.getId() + 
                                       " | FullName: " + userAfter.getFullname() + 
                                       " | Time: " + new Date());
                }
            } catch (IllegalStateException e) {
                // Log thông báo session hủy, không làm server bị crash
                System.out.println("[LoggerFilter] Session đã bị hủy sau khi xử lý (thường là Logout).");
            }
        }
	}
}