package poly.com.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.OneToMany;
import lombok.Data;
import lombok.AllArgsConstructor;
import lombok.NoArgsConstructor;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name = "Users")
public class User {
	@Id
	@Column(name = "Id")
	private String id;
	
	@Column(name = "Password", nullable = false)
	private String password;
	
	@Column(name = "Email", unique = true, nullable = false)
	private String email;
	
	@Column(name = "Fullname")
	private String fullname;
	
	@Column(name = "Admin")
	private boolean admin = false;
	
	@OneToMany(mappedBy = "user") 
    private List<Favorite> favorites;
    
    @OneToMany(mappedBy = "user") 
    private List<Share> shares;
}
