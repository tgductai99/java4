package poly.com.listener;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebListener;
import jakarta.servlet.http.*;

@WebListener
public class AppListener implements ServletContextListener, HttpSessionListener {

    public static final String VISITORS_COUNT = "visitors";

    // Khởi tạo (Khi Web App deploy thành công)
    @Override
    public void contextInitialized(ServletContextEvent sce) {
        // Khởi tạo bộ đếm trong Application Scope
        sce.getServletContext().setAttribute(VISITORS_COUNT, 0); 
        System.out.println("LISTENER: Bộ đếm Visitors đã được khởi tạo.");
    }

    // Đếm khách (Khi có Session mới được tạo)
    @Override
    public void sessionCreated(HttpSessionEvent se) {
        ServletContext application = se.getSession().getServletContext();
        Integer count = (Integer) application.getAttribute(VISITORS_COUNT);
        
        // Tăng số đếm và cập nhật lại vào Application Scope
        application.setAttribute(VISITORS_COUNT, count + 1);
        System.out.println("LISTENER: Session mới. Tổng truy cập: " + (count + 1));
    }
    
    // Các phương thức khác: contextDestroyed, sessionDestroyed
    // ... (có thể bỏ qua nếu không cần lưu lại vào file/CSDL khi tắt app)
}