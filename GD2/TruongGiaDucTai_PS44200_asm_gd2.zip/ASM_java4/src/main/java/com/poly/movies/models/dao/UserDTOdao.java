package com.poly.movies.models.dao;

import com.poly.movies.models.entities.UserDTO;

public interface UserDTOdao extends CrudDAO<UserDTO, String> {

}
