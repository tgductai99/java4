-- 1. Tạo Database (nếu chưa tồn tại)
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'PolyOE')
BEGIN
    CREATE DATABASE PolyOE;
END
GO

USE PolyOE;
GO

-- 2. Xóa các bảng nếu tồn tại
IF OBJECT_ID('dbo.Favorites', 'U') IS NOT NULL DROP TABLE dbo.Favorites;
IF OBJECT_ID('dbo.Shares', 'U') IS NOT NULL DROP TABLE dbo.Shares;
IF OBJECT_ID('dbo.Report', 'U') IS NOT NULL DROP TABLE dbo.Report;
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID('dbo.Videos', 'U') IS NOT NULL DROP TABLE dbo.Videos;
GO


-- 3. Tạo bảng chính
CREATE TABLE Users(
    Id NVARCHAR(50) PRIMARY KEY,
    Password NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Fullname NVARCHAR(100),
    Admin BIT DEFAULT 0
);

CREATE TABLE Videos(
    Id NVARCHAR(50) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Poster NVARCHAR(255),
    Views INT DEFAULT 0,
    Description NVARCHAR(MAX),
    Category NVARCHAR(50) NULL,
    Active BIT DEFAULT 1
);

CREATE TABLE Favorites (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId NVARCHAR(50) NOT NULL,
    VideoId NVARCHAR(50) NOT NULL,
    LikeDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE CASCADE
);

CREATE TABLE Shares (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId NVARCHAR(50) NOT NULL,
    VideoId NVARCHAR(50) NOT NULL,
    Emails NVARCHAR(255),
    ShareDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE CASCADE
);

CREATE TABLE Report (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Groupp NVARCHAR(100),
    Likes INT DEFAULT 0,
    Newest NVARCHAR(255),
    Oldest NVARCHAR(255),
    Date DATE DEFAULT GETDATE()
);
GO


-- 4. Chèn dữ liệu Users
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
(N'NV001', N'ABC', N'LEE ANH TU', N'TULA12@FE.EDU.VN', 1),
(N'NV002', N'123', N'ANH TÚ', N'leanhtu@GMAIL.COM', 1),
(N'NV003', N'321', N'Nguyễn Nhật Cao Thăng', N'thangncc@fpt.edu.vn', 0),
(N'NV004', N'321', N'Phan Nguyễn Đăng Trường', N'truongpnd@fpt.edu.vn', 0),
(N'NV006', N'123', N'Vương Ngọc Thanh Loan', N'loan@gmail.com', 0),
(N'NV007', N'123', N'Nguyễn Thanh Vũ', N'vu@gmail.com', 0),
(N'NV008', N'123', N'Phạm Đồng Đại', N'dai@gmail.com', 0),
(N'NV009', N'321', N'Trần Thị Ánh Tuyết', N'tuyet@gmail.com', 0),
(N'NV010', N'321', N'Trần Thị Ánh Tuyết2', N'tuyet2@gmail.com', 0),
(N'NV011', N'pass11', N'Nguyễn Văn Tèo', N'teonv@gmail.com', 0),
(N'NV012', N'pass12', N'Nguyễn Văn B', N'vanb@gmail.com', 0),
(N'NV013', N'pass13', N'Nguyễn Văn C', N'vanc@gmail.com', 0),
(N'NV014', N'pass14', N'Nguyễn Văn D', N'vand@gmail.com', 0),
(N'NV015', N'pass15', N'Nguyễn Văn E', N'vane@gmail.com', 0);


-- 5. Chèn dữ liệu Videos (đã thêm Category đầy đủ)
INSERT INTO Videos (Id, Title, Poster, Description, Active, Views, Category) VALUES
-- MUSIC
(N'vd001', N'W/n - 3107 3 ( Official Video ) ft. Nâu, Duongg, Titie', N'kfw7MYah2n0', N'Sáng tác & Music Producer : W/n Rap : Nâu...', 1, 100, 'Music'),
(N'vd002', N'QUÂN A.P - BÔNG HOA ĐẸP NHẤT', N'e2Xx7WcvEns', N'BÔNG HOA ĐẸP NHẤT Singer: Quân A.P...', 1, 100, 'Music'),
(N'vd003', N'Ánh Sao Và Bầu Trời - T.R.I', N'9vaLkYElidg', N'Performer: T.R.I...', 1, 100, 'Music'),
(N'vd004', N'hieuthuhai - ngủ một mình', N'1OJQdxT6WHE', N'Produced by Dargon...', 1, 100, 'Music'),
(N'vd005', N'Lửng Lơ | Masew x Bray', N'HehotFZ8BGo', N'Một sản phẩm thực hiện bởi Great Entertainment...', 1, 100, 'Music'),
(N'vd006', N'MONO - Waiting For You', N'CHw1b_1LVBA', N'Nghệ sĩ biểu diễn : MONO...', 1, 100, 'Music'),
(N'vd007', N'HIEUTHUHAI - Vệ Tinh', N'TTwlhJzXHo4', N'Artist: HIEUTHUHAI...', 1, 100, 'Music'),
(N'vd008', N'An Thần (ft. Thắng) | Low G', N'J7eYhM6wXPo', N'Produced by Thắng...', 1, 100, 'Music'),
(N'vd009', N'Nơi Này Có Anh | Sơn Tùng', N'FN7ALfpGxiI', N'Viết bởi Sơn Tùng M-TP...', 1, 100, 'Music'),
(N'vd010', N'BLACKPINK - Pink Venom', N'gQlMMD8auMs', N'From BLACKPINK...', 1, 100, 'Music'),

-- COMEDY (Vân Sơn)
(N'vd011', N'Hài Kịch | TRẦN MINH KHỐ CHUỐI', N'XTEHX-5rjpo', N'© VAN SON ENTERTAINMENT...', 1, 100, 'Comedy'),
(N'vd012', N'Hài Kịch | 2 LÁ THƯ', N'VUDZ2LAyFGc', N'© VAN SON ENTERTAINMENT...', 1, 100, 'Comedy'),
(N'vd013', N'Hài | HAI ĐẤT 3 RUỘNG', N'LsLJCb0jQqI', N'© VAN SON ENTERTAINMENT...', 1, 100, 'Comedy'),
(N'vd014', N'HẮC BẠCH CÔNG TỬ', N'Q03GEFCi-cM', N'© VAN SON ENTERTAINMENT...', 1, 100, 'Comedy'),
(N'vd015', N'SƠN TINH THUỶ TINH', N'7Ez2_bxvExk', N'© VAN SON ENTERTAINMENT...', 1, 100, 'Comedy'),

-- ACTION
(N'vd016', N'KHÔNG ĐỐI THỦ | Phim 567', N'asr5mXryAZU', N'MÃNH HỔ HẠ SƠN', 1, 100, 'Action'),
(N'vd017', N'MÃNH TƯỚNG VỀ LÀNG', N'uMVRgpL_pzQ', N'Mãnh Hổ Hạ Sơn...', 1, 100, 'Action'),
(N'vd018', N'CHIẾN LANG - PHẦN CUỐI', N'hDuttHj9WWw', N'Nội dung phim...', 1, 1000, 'Action'),
(N'vd019', N'NGƯỜI VẬN CHUYỂN - Phần Cuối', N's7lY5w51a8c', N'Phần phim mới...', 1, 1000, 'Action'),
(N'vd020', N'Mật Danh Iris | Full HD', N'3uFpxJu-lbA', N'Phim Hàn Quốc...', 1, 500, 'Action'),
(N'vd021', N'Tay Bắn Tỉa: Báo Thù', N'7ZlX6H1CerE', N'Nữ xạ thủ...', 1, 500, 'Action'),
(N'vd022', N'Vua Bắn Tỉa: Ám Sát', N'K8mZVqAQofs', N'Nội dung phim...', 1, 500, 'Action'),
(N'vd023', N'Cuộc Giải Cứu Cáo Đen', N'DIeQidmCM84', N'Năm 1945...', 1, 800, 'Action'),
(N'vd024', N'XẠ THỦ - ĐỘI ĐỘT KÍCH HỒNG ƯNG', N'efFUtxO60FI', N'Đạo diễn...', 1, 800, 'Action'),
(N'vd025', N'TRÁNG SĨ XUẤT KÍCH', N'phgY-ovAaDc', N'Đạo diễn...', 1, 700, 'Action'),
(N'vd026', N'XUYÊN KHÔNG TIỂU TỬ | Thành Long', N'wDawU0fBD5o', N'Diễn viên...', 1, 200, 'Action'),
(N'vd027', N'SỨC MẠNH CỦA RỒNG - Phần Cuối', N'uRwPB-_O9cE', N'Nội dung phim...', 1, 300, 'Action'),

-- REVIEW
(N'vd028', N'Review Phim Big Mouth', N'egwCJMkFmHU', N'Tóm tắt Big Mouth...', 1, 400, 'Review'),
(N'vd029', N'Review Phim Bị Cáo', N'7LJHsz8Ldno', N'Nội dung phim...', 1, 300, 'Review'),
(N'vd030', N'Review Phim: Tội Ác Vô Hình', N'T2nNe915ebk', N'Câu chuyện...', 1, 1500, 'Review'),

-- OTHER
(N'vd031', N'Anh Tú', N'abc', N'fd', 1, 2000, 'Other');



-- 6. Chèn dữ liệu Favorites
SET IDENTITY_INSERT [dbo].[Favorites] ON;
INSERT INTO Favorites (Id, VideoId, UserId, LikeDate) VALUES
(2, N'vd001', N'NV002', '2023-03-10'),
(4, N'vd002', N'NV003', '2023-03-01'),
(5, N'vd002', N'NV004', '2023-03-11'),
(34, N'vd020', N'NV001', '2023-03-27'),
(45, N'vd014', N'NV001', '2023-03-27'),
(46, N'vd007', N'NV002', '2024-03-27'),
(78, N'vd001', N'NV001', '2024-03-27'),
(80, N'vd001', N'NV003', '2024-03-27'),
(90, N'vd008', N'NV002', '2024-03-27'),
(91, N'vd008', N'NV001', '2022-04-28'),
(95, N'vd002', N'NV001', '2025-03-18');
SET IDENTITY_INSERT [dbo].[Favorites] OFF;


-- 7. Stored Procedure
IF OBJECT_ID('dbo.spFavoriteByYear') IS NOT NULL
    DROP PROCEDURE dbo.spFavoriteByYear;
GO

CREATE PROC [dbo].[spFavoriteByYear](@year INT)
AS
BEGIN
	SELECT
		v.Title AS 'groupp',
		v.Category,
		COUNT(f.Id) AS 'likes',
        MAX(f.LikeDate) AS 'newest',
        MIN(f.LikeDate) AS 'oldest'
	FROM Favorites f
	JOIN Videos v ON f.VideoId = v.Id
	WHERE YEAR(f.LikeDate) = @year
	GROUP BY v.Title, v.Category;
END
GO
