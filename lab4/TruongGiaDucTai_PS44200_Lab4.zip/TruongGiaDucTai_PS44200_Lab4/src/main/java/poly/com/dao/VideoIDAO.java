package poly.com.dao;

import java.util.List;
import poly.com.entity.Video;

public interface VideoIDAO extends ICRUD<Video, String> {
    List<Video> findActiveVideos();
    
    List<Video> findTopNViewedVideos(int topN);
}