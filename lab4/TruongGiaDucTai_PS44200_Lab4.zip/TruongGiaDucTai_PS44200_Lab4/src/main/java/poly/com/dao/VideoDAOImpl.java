package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.entity.Video;

public class VideoDAOImpl extends AbstractDAO<Video, String> implements VideoIDAO {

    public VideoDAOImpl() {
        super(Video.class);
    }

    @Override
    public List<Video> findActiveVideos() {
        return executeQuery(em -> {
            String jpql = "SELECT v FROM Video v WHERE v.active = true";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            return query.getResultList();
        });
    }

    @Override
    public List<Video> findTopNViewedVideos(int topN) {
        return executeQuery(em -> {
            String jpql = "SELECT v FROM Video v ORDER BY v.views DESC";
            TypedQuery<Video> query = em.createQuery(jpql, Video.class);
            query.setMaxResults(topN);
            return query.getResultList();
        });
    }

}