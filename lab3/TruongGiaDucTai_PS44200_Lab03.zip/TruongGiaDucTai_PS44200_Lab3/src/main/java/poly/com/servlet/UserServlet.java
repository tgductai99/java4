package poly.com.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import poly.com.dao.UserDAOImpl;
import poly.com.dao.UserIDAO;
import poly.com.entity.User;

import java.io.IOException;
import java.util.List;

import org.apache.commons.beanutils.BeanUtils;

/**
 * Servlet implementation class UserServlet
 */
@WebServlet({ "/user/index", "/user/create", "/user/update", "/user/delete", "/user/reset", "/user/edit/*",
		"/user/delete/*", })
public class UserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private UserIDAO dao;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserServlet() {
		super();
		dao = new UserDAOImpl();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String url = request.getRequestURL().toString();

		User user = null;

		if (url.contains("/user/delete")) {
			String id = request.getParameter("id");
			String pathInfo = request.getPathInfo();

			if ((id == null || id.isEmpty()) && pathInfo != null) {
				id = pathInfo.substring(1);
			}
			if (id != null && !id.isEmpty()) {
				dao.delete(id);
				request.setAttribute("message", "Delete success!");
			}

			user = new User();
			request.setAttribute("user", user);
		} else if (url.contains("/user/edit")) {
			String id = request.getParameter("id");
			String pathInfo = request.getPathInfo();
			if ((id == null || id.isEmpty()) && pathInfo != null) {
				id = pathInfo.substring(1);
			}
			if (id != null && !id.isEmpty()) {
				user = dao.findById(id);
			}
			request.setAttribute("user", user);
		}

		findAll(request, response);
		request.getRequestDispatcher("/views/user.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.setCharacterEncoding("UTF-8");
		response.setContentType("text/html;charset=UTF-8");

		String url = request.getRequestURL().toString();

		if (url.contains("/user/create")) {
			create(request, response);
		} else if (url.contains("/user/update")) {
			update(request, response);
		} else if (url.contains("/user/delete")) {
			delete(request, response);
		} else if (url.contains("/user/reset")) {
			request.setAttribute("user", new User());
		}

		findAll(request, response);
		request.getRequestDispatcher("/views/user.jsp").forward(request, response);
	}

	private void create(HttpServletRequest request, HttpServletResponse response) {
	    try {
	        User user = new User();
	        BeanUtils.populate(user, request.getParameterMap());
	        if (dao.findById(user.getId()) != null) {
	            request.setAttribute("error", "ID đã tồn tại, vui lòng nhập ID khác!");
	        } else {
	            dao.create(user);
	            request.setAttribute("message", "Create success!");
	        }
	    } catch (Exception e) {
	        e.printStackTrace();
	        request.setAttribute("error", "Error: " + e.getMessage());
	    }
	}


	private void update(HttpServletRequest request, HttpServletResponse response) {
		try {
			User user = new User();
			BeanUtils.populate(user, request.getParameterMap());
			dao.update(user);
			request.setAttribute("message", "Update success!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	private void delete(HttpServletRequest request, HttpServletResponse response) {
		try {
			User user = new User();
			BeanUtils.populate(user, request.getParameterMap());
			if (user.getId() != null) {
				dao.delete(user.getId());
			}
			request.setAttribute("message", "Delete success!");
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

	private void findAll(HttpServletRequest request, HttpServletResponse response) {
		try {
			List<User> list = dao.findAll();
			request.setAttribute("users", list);
		} catch (Exception e) {
			e.printStackTrace();
			request.setAttribute("error", "Error: " + e.getMessage());
		}
	}

}
