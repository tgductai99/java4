package poly.com.dao;

import java.util.List;

public interface ICRUD<T, K> {
	void create(T entity);
	
	void update(T entity);
	
	void delete(K id);
	
	T findById(K id);
	
	List<T> findAll();
}
