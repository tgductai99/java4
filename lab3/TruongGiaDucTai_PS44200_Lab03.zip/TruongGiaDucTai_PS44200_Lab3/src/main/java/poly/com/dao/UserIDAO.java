package poly.com.dao;

import java.util.List;
import poly.com.entity.User;

public interface UserIDAO extends ICRUD<User, String> {
	List<User> findByEmailDomain(String domain);

	List<User> findAdmins();

	List<User> findUsersInPage(int pageNumber, int pageSize);
}
