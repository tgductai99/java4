package poly.com.servlet;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import org.apache.commons.beanutils.BeanUtils;

import poly.com.model.User;
import poly.com.dao.UserDAO;
import poly.com.dao.UserDAOImpl;

@WebServlet({ "/", "/user/index", "/user/create", "/user/update", "/user/delete", "/user/reset", "/user/edit/*",
		"/user/delete-get/*", })
public class UserCRUDServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	private UserDAO userDAO = new UserDAOImpl();

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");

		String uri = req.getRequestURI();
		User user = null;

		try {
			if (uri.contains("/delete-get/")) {
				String pathInfo = req.getPathInfo();
				String id = pathInfo != null ? pathInfo.substring(1) : null;

				if (id != null && !id.isEmpty()) {
					userDAO.delete(id);
					req.setAttribute("message", "Delete success! User ID: " + id);
				} else {
					req.setAttribute("error", "Error: User ID is missing for deletion.");
				}
				user = new User();
				req.setAttribute("user", user);

			} else if (uri.contains("/edit/")) {
				String pathInfo = req.getPathInfo();
				String id = pathInfo != null ? pathInfo.substring(1) : null;

				if (id != null && !id.isEmpty()) {
					user = userDAO.findById(id);
				}
				req.setAttribute("user", user);
			}

			if (user == null) {
				req.setAttribute("user", new User());
			}

		} catch (RuntimeException e) {
			e.printStackTrace();
			req.setAttribute("error", "Database Error: " + e.getMessage());
			if (req.getAttribute("user") == null) {
				req.setAttribute("user", new User());
			}
		}

		this.findAll(req, resp);
		req.getRequestDispatcher("/views/user-crud.jsp").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.setCharacterEncoding("UTF-8");
		resp.setContentType("text/html;charset=UTF-8");

		String url = req.getRequestURL().toString();
		User user = new User();

		try {
			BeanUtils.populate(user, req.getParameterMap());
			req.setAttribute("user", user);

			if (url.contains("create")) {
				this.create(req, resp, user);
			} else if (url.contains("update")) {
				this.update(req, resp, user);
			} else if (url.contains("delete")) {
				this.delete(req, resp, user);
			} else if (url.contains("reset")) {
				req.setAttribute("user", new User());
				req.setAttribute("message", "Form reset successful.");
			}
		} catch (RuntimeException | IllegalAccessException | InvocationTargetException e) {
			e.printStackTrace();
			req.setAttribute("error", "Error: " + e.getMessage());
			// Giữ lại dữ liệu người dùng đã nhập nếu có lỗi
			if (req.getAttribute("user") == null) {
				req.setAttribute("user", new User());
			}
		}

		this.findAll(req, resp);
		req.getRequestDispatcher("/views/user-crud.jsp").forward(req, resp);
	}

	protected void create(HttpServletRequest req, HttpServletResponse resp, User user)
			throws ServletException, IOException {
		userDAO.create(user);
		req.setAttribute("message", "Create success!");
		req.setAttribute("user", new User());
	}

	protected void update(HttpServletRequest req, HttpServletResponse resp, User user)
			throws ServletException, IOException {
		userDAO.update(user);
		req.setAttribute("message", "Update success!");
	}

	protected void delete(HttpServletRequest req, HttpServletResponse resp, User user)
			throws ServletException, IOException {
		if (user.getId() != null) {
			userDAO.delete(user.getId());
			req.setAttribute("message", "Delete success!");
		} else {
			req.setAttribute("error", "Error: User ID is required for deletion.");
		}
		req.setAttribute("user", new User());
	}

	protected void findAll(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		try {
			List<User> users = userDAO.findAll();
			req.setAttribute("users", users);
		} catch (Exception e) {
			e.printStackTrace();
			if (req.getAttribute("error") == null) {
				req.setAttribute("error", "Error loading user list: " + e.getMessage());
			}
		}
	}
}