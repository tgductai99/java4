package poly.com.dao;

import java.util.List;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class UserDAOImpl extends AbstractCRUD<User, String> implements UserDAO {

    public UserDAOImpl() {
        super(User.class);
    }

    @Override
    public List<User> findByEmailDomain(String domain) {
        return executeQuery(em -> {
            String jpql = "SELECT u FROM User u WHERE u.email LIKE :email";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setParameter("email", "%" + domain);
            return query.getResultList();
        });
    }

    @Override
    public List<User> findAdmins() {
        return executeQuery(em -> {
            String jpql = "SELECT u FROM User u WHERE u.admin = true";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            return query.getResultList();
        });
    }

    @Override
    public List<User> findUsersInPage(int pageNumber, int pageSize) {
        return executeQuery(em -> {
            String jpql = "SELECT u FROM User u ORDER BY u.id";
            TypedQuery<User> query = em.createQuery(jpql, User.class);
            query.setFirstResult(pageNumber * pageSize);
            query.setMaxResults(pageSize);
            return query.getResultList();
        });
    }
}