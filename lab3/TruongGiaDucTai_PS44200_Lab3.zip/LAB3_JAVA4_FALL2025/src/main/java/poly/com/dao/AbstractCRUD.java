package poly.com.dao;

import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import poly.com.utils.JpaUtils;

public abstract class AbstractCRUD<T, K> implements ICRUD<T, K>{
    protected Class<T> entityClass;

    public AbstractCRUD(Class<T> entityClass) {
        this.entityClass = entityClass;
    }
    
    protected void executeTransaction(Consumer<EntityManager> action) {
        EntityManager em = JpaUtils.getEntityManager();
        try {
            em.getTransaction().begin();
            action.accept(em); 
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            System.err.println("LỖI GIAO DỊCH tại " + entityClass.getSimpleName());
            e.printStackTrace();
            throw new RuntimeException("Thao tác dữ liệu thất bại.", e); 
        } finally {
            em.close();
        }
    }

    protected <R> R executeQuery(Function<EntityManager, R> function) {
        EntityManager em = JpaUtils.getEntityManager();
        try {
            return function.apply(em);
        } finally {
            em.close();
        }
    }

    @Override
    public void create(T entity) {
        executeTransaction(em -> em.persist(entity)); 
    }

    @Override
    public void update(T entity) {
        executeTransaction(em -> em.merge(entity));
    }

    @Override
    public void delete(K id) {
        executeTransaction(em -> {
            T entity = em.find(entityClass, id);
            if (entity != null) {
                em.remove(entity);
            }
        });
    }

    @Override
    public T findById(K id) {
        return executeQuery(em -> em.find(entityClass, id));
    }

    @Override
    public List<T> findAll() {
        return executeQuery(em -> {
            String jpql = "SELECT e FROM " + entityClass.getSimpleName() + " e";
            TypedQuery<T> query = em.createQuery(jpql, entityClass);
            return query.getResultList();
        });
    }
}
