package poly.com.dao;

import java.util.List;

/**
 * Interface định nghĩa các thao tác CRUD cơ bản cho mọi Entity.
 * T: Entity Class (ví dụ: User)
 * K: Primary Key Type (ví dụ: String)
 */
public interface ICRUD<T, K> {

    void create(T entity);

    void update(T entity);

    void delete(K id);

    T findById(K id);

    List<T> findAll();
}