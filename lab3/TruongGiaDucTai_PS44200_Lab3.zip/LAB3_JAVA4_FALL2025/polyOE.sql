-- 1. Cấu hình Database
-- Tạo Database (nếu chưa tồn tại)
IF NOT EXISTS (SELECT name FROM sys.databases WHERE name = N'PolyOE')
BEGIN
    CREATE DATABASE PolyOE;
END
GO

USE PolyOE;
GO

-- 2. Xóa các bảng nếu chúng đã tồn tại để đảm bảo script chạy lại được (tùy chọn)
IF OBJECT_ID('dbo.Favorites', 'U') IS NOT NULL DROP TABLE dbo.Favorites;
IF OBJECT_ID('dbo.Shares', 'U') IS NOT NULL DROP TABLE dbo.Shares;
IF OBJECT_ID('dbo.Report', 'U') IS NOT NULL DROP TABLE dbo.Report;
IF OBJECT_ID('dbo.Users', 'U') IS NOT NULL DROP TABLE dbo.Users;
IF OBJECT_ID('dbo.Videos', 'U') IS NOT NULL DROP TABLE dbo.Videos;
GO


-- 3. Tạo Bảng
CREATE TABLE Users(
    Id NVARCHAR(50) PRIMARY KEY,
    Password NVARCHAR(255) NOT NULL,
    Email NVARCHAR(100) UNIQUE NOT NULL,
    Fullname NVARCHAR(100),
    Admin BIT DEFAULT 0
);

CREATE TABLE Videos(
    Id NVARCHAR(50) PRIMARY KEY,
    Title NVARCHAR(255) NOT NULL,
    Poster NVARCHAR(255),
    Views INT DEFAULT 0,
    Description NVARCHAR(MAX),
    Active BIT DEFAULT 1
);

CREATE TABLE Favorites (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId NVARCHAR(50) NOT NULL,
    VideoId NVARCHAR(50) NOT NULL,
    LikeDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE CASCADE
);

CREATE TABLE Shares (
    Id BIGINT IDENTITY(1,1) PRIMARY KEY,
    UserId NVARCHAR(50) NOT NULL,
    VideoId NVARCHAR(50) NOT NULL,
    Emails NVARCHAR(255),
    ShareDate DATE DEFAULT GETDATE(),
    FOREIGN KEY (UserId) REFERENCES Users(Id) ON DELETE CASCADE,
    FOREIGN KEY (VideoId) REFERENCES Videos(Id) ON DELETE CASCADE
);

CREATE TABLE Report (
    Id INT IDENTITY(1,1) PRIMARY KEY,
    Groupp NVARCHAR(100),
    Likes INT DEFAULT 0,
    Newest NVARCHAR(255),
    Oldest NVARCHAR(255),
    Date DATE DEFAULT GETDATE()
);
GO


-- 4. Chèn Dữ liệu Mẫu (Dữ liệu PolyOE1 được làm sạch)

-- Bảng Users
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
(N'NV001', N'ABC', N'LEE ANH TU', N'TULA12@FE.EDU.VN', 1),
(N'NV002', N'123', N'ANH TÚ', N'leanhtu@GMAIL.COM', 1),
(N'NV003', N'321', N'Nguyễn Nhật Cao Thăng', N'thangncc@fpt.edu.vn', 0),
(N'NV004', N'321', N'Phan Nguyễn Đăng Trường', N'truongpnd@fpt.edu.vn', 0),
(N'NV006', N'123', N'Vương Ngọc Thanh Loan', N'loan@gmail.com', 0),
(N'NV007', N'123', N'Nguyễn Thanh Vũ', N'vu@gmail.com', 0),
(N'NV008', N'123', N'Phạm Đồng Đại', N'dai@gmail.com', 0),
(N'NV009', N'321', N'Trần Thị Ánh Tuyết', N'tuyet@gmail.com', 0);

-- Bảng Videos (Loại bỏ khoảng trắng thừa ở Id)
INSERT INTO Videos (Id, Title, Poster, Description, Active, Views) VALUES
(N'vd001', N'W/n - 3107 3 ( Official Video ) ft. Nâu, Duongg, Titie', N'kfw7MYah2n0', N'Sáng tác & Music Producer : W/n Rap : Nâu...', 1, 100),
(N'vd002', N'QUÂN A.P - BÔNG HOA ĐẸP NHẤT [OFFICIAL LYRICS VIDEO]', N'e2Xx7WcvEns', N'BÔNG HOA ĐẸP NHẤT Singer: Quân A.P Composer: Vũ Hà Anh...', 1, 100),
(N'vd003', N'Ánh Sao Và Bầu Trời - T.R.I x Cá | [Official Audio]', N'9vaLkYElidg', N'Performer: T.R.I Music Producer: T.R.I Composer: Cá (B3212)...', 1, 100),
(N'vd004', N'hieuthuhai - ngủ một mình (tình rất tình) ft. negav (prod. by kewtiie)', N'1OJQdxT6WHE', N'Produced by Dargon Executive producer: Ai Nguyen...', 1, 100),
(N'vd005', N'Lửng Lơ | MASEW x BRAY ft. RedT x Ý Tiên | MV OFFICIAL', N'HehotFZ8BGo', N'Một sản phẩm thực hiện bởi Great Entertainment...', 1, 100),
(N'vd006', N'MONO - Waiting For You (Album 22 - Track No.10)', N'CHw1b_1LVBA', N'* Nghệ sĩ biểu diễn : MONO, Onionn...', 1, 100),
(N'vd007', N'HIEUTHUHAI - Vệ Tinh ft. Hoàng Tôn (prod. by Kewtiie) | OFFICIAL MV', N'TTwlhJzXHo4', N'Artist: HIEUTHUHAI & HOÀNG TÔN Music Composer: HIEUTHUHAI...', 1, 100),
(N'vd008', N'An Thần (ft. Thắng) | Low G | Rap Nhà Làm', N'J7eYhM6wXPo', N'Produced by Thắng & Chí Trung Mix n'' Mastered by Thắng...', 1, 100),
(N'vd009', N'NƠI NÀY CÓ ANH | OFFICIAL MUSIC VIDEO | SƠN TÙNG M-TP', N'FN7ALfpGxiI', N'Được thực hiện bởi / Video made by Sáng tác / Composer: Sơn Tùng M-TP...', 1, 100),
(N'vd010', N'BLACKPINK - ‘Pink Venom’ M/V', N'gQlMMD8auMs', N'More about BLACKPINK...', 1, 100),
(N'vd011', N'VAN SON 😊 Hài Kịch | TRẦN MINH KHỐ CHUỐI Vân Sơn - Bảo Liêm', N'XTEHX-5rjpo', N'©VAN SON ENTERTAINMENT, INC. ALL RIGHTS RESERVED...', 1, 100),
(N'vd012', N'VAN SON 😊 Hài kịch | 2 LÁ THƯ | Vân Sơn - Bảo Liêm - Quang Minh - Hồng Đào', N'VUDZ2LAyFGc', N'©VAN SON ENTERTAINMENT, INC. ALL RIGHTS RESERVED...', 1, 100),
(N'vd013', N'VAN SON 😊 San Jose | Hài Kịch HAI ĐẤT 3 RUỘNG | Vân Sơn - Bảo Liêm - Giáng Ngọc', N'LsLJCb0jQqI', N'©VAN SON ENTERTAINMENT, INC. ALL RIGHTS RESERVED...', 1, 100),
(N'vd014', N'VAN SON 😊 Ca Nhạc Hài | HẮC BẠCH CÔNG TỬ | Vân Sơn - Hoài Linh - Hồng Đào - Úp Mập - Bé Mập', N'Q03GEFCi-cM', N'©VAN SON ENTERTAINMENT, INC. ALL RIGHTS RESERVED...', 1, 100),
(N'vd015', N'VAN SON 😊 Hài Kinh Điển | SƠN TINH THUỶ TINH | Vân Sơn - Bảo Liêm - Văn Chung', N'7Ez2_bxvExk', N'©VAN SON ENTERTAINMENT, INC. ALL RIGHTS RESERVED...', 1, 100),
(N'vd016', N'Phim Lẻ Hay 2023 | KHÔNG ĐỐI THỦ | Phim Hành Động Võ Thuật Cỗ Trang Mới Nhất | Full HD | Phim 567', N'asr5mXryAZU', N'Tên Phim: MÃNH HỔ HẠ SƠN', 1, 100),
(N'vd017', N'MÃNH TƯỚNG VỀ LÀNG | Phim Mới 2023 | Phim Võ Thuật Cổ Trang Đặc Sắc Hay Nhất 2023 | 4K HD | Clip Hay', N'uMVRgpL_pzQ', N'🔥 Tên phim : Mãnh Hổ Hạ Sơn 🔥...', 1, 100),
(N'vd018', N'PHIM HÀNH ĐỘNG VÕ THUẬT KINH ĐIỂN | CHIẾN LANG - PHẦN CUỐI | Phim Hành Động Võ Thuật Hay Nhất', N'hDuttHj9WWw', N'❖ Nội Dung Phim CHIẾN LANG - PHẦN CUỐI :...', 1, 1000),
(N'vd019', N'PHIM HÀNH ĐỘNG CHIẾU RẠP 2020 | NGƯỜI VẬN CHUYỂN - Phần Cuối | Phim Hành Động Mỹ 2020', N's7lY5w51a8c', N'Phần phim mới của series Người vận chuyển có tên gọi...', 1, 1000),
(N'vd020', N'Phim Bom Tấn Hàn Quốc Chiếu Rạp - Mật Danh Iris | Lee Byung Hun, Kim Tae Hee, Top Big Bang', N'3uFpxJu-lbA', N'• Thể loại: Phim Hàn, Tâm Lý, Tình Cảm, Viễn Tưởng...', 1, 500),
(N'vd021', N'[VIETSUB] Tay Bắn Tỉa: Báo Thù | Sniper Vengeance | Phim Lẻ YOUKU', N'7ZlX6H1CerE', N'Nữ xạ thủ tài ba Anna buộc phải nhận nhiệm vụ ám sát...', 1, 500),
(N'vd022', N'[VIETSUB] Vua Bắn Tỉa: Ám Sát - The King of Snipers | Phim Lẻ YOUKU', N'K8mZVqAQofs', N'Nữ xạ thủ tài ba Anna buộc phải nhận nhiệm vụ ám sát...', 1, 500),
(N'vd023', N'[VIETSUB] Cuộc Giải Cứu Của Tiểu Đội Cáo Đen - Black Fox: Ultimate Rescue | Phim Lẻ YOUKU', N'DIeQidmCM84', N'Năm 1945, chuyên gia quân sự Liên Xô...', 1, 800),
(N'vd024', N'Siêu Phẩm Hành Động Kháng Nhật Mới Nhất 2020 | XẠ THỦ - ĐỘI ĐỘT KÍCH HỒNG ƯNG | Thuyết Minh', N'efFUtxO60FI', N'✤ Đạo diễn: Lý Kiện Khôi...', 1, 800),
(N'vd025', N'[Thuyết Minh] TRÁNG SĨ XUẤT KÍCH | Phim Chiến Tranh Kháng Nhật Cực Hay | Phim Lẻ Mới Nhất 2020', N'phgY-ovAaDc', N'✤ Đạo diễn: Dương Hổ...', 1, 700),
(N'vd026', N'Phim Lẻ bởi Thành Long 2022: XUYÊN KHÔNG TIỂU TỬ (Thuyết Minh) | Phim Hành Động Võ Thuật Đỉnh Cao', N'wDawU0fBD5o', N'Diễn Viên: Hồ Ca, Bạch Băng, Trần Tử Hàm...', 1, 200),
(N'vd027', N'PHIM HÀNH ĐỘNG CHIẾU RẠP 2020 | SỨC MẠNH CỦA RỒNG - Phần Cuối | Phim Hành Động Võ Thuật Hay Nhất', N'uRwPB-_O9cE', N'Phim Sức Mạnh Của Rồng nhận lệnh Peter Đại Đế...', 1, 300),
(N'vd028', N'Review Phim Big Mouth (2022) Bản Full | Tóm Tắt Phim Big Mouth | Lee Jong Suk và Yoona', N'egwCJMkFmHU', N'Phim: Big Mouth (2022) Bộ phim Big Mouth kể về câu chuyện...', 1, 400),
(N'vd029', N'Review Phim Bị cáo Bản Full - Tóm Tắt Phim Innocent Defend 2017 | Ji Sung', N'7LJHsz8Ldno', N'nội dung phim: Phim Bị Cáo bắt đầu khi Park Jung-Woo...', 1, 300),
(N'vd030', N'Review Phim: Tội Ác Vô Hình | Blind | Bản Full | Tập 1-16 | Taecyeon | Ha Seok Jin | Jung Eun Ji', N'T2nNe915ebk', N'Tội ác vô hình là câu chuyện kể về cuộc đời Ryu Sung Joon...', 1, 1500),
(N'vd031', N'Anh Tú', N'abc', N'fd', 1, 2000);

-- Bảng Favorites (Sử dụng IDENTITY_INSERT để chèn Id gốc và loại bỏ khoảng trắng thừa ở VideoId)
SET IDENTITY_INSERT [dbo].[Favorites] ON;
INSERT INTO Favorites (Id, VideoId, UserId, LikeDate) VALUES
(2, N'vd001', N'NV002', CAST(N'2023-03-10' AS Date)),
(4, N'vd002', N'NV003', CAST(N'2023-03-01' AS Date)),
(5, N'vd002', N'NV004', CAST(N'2023-03-11' AS Date)),
(34, N'vd020', N'NV001', CAST(N'2023-03-27' AS Date)),
(45, N'vd014', N'NV001', CAST(N'2023-03-27' AS Date)),
(46, N'vd007', N'NV002', CAST(N'2024-03-27' AS Date)),
(78, N'vd001', N'NV001', CAST(N'2024-03-27' AS Date)),
(80, N'vd001', N'NV003', CAST(N'2024-03-27' AS Date)),
(90, N'vd008', N'NV002', CAST(N'2024-03-27' AS Date)),
(91, N'vd008', N'NV001', CAST(N'2022-04-28' AS Date)),
(95, N'vd002', N'NV001', CAST(N'2025-03-18' AS Date));
SET IDENTITY_INSERT [dbo].[Favorites] OFF;
GO

-- 5. Tạo Stored Procedure
-- Xóa Proc cũ nếu tồn tại
IF OBJECT_ID('dbo.spFavoriteByYear') IS NOT NULL
    DROP PROCEDURE dbo.spFavoriteByYear;
GO

-- Tạo Proc mới
CREATE PROC [dbo].[spFavoriteByYear](@year INT)
AS
BEGIN
	SELECT
		v.Title AS 'groupp',
		COUNT(f.Id) AS 'likes',
		MAX(f.LikeDate) AS 'newest',
		MIN(f.LikeDate) AS 'oldest'
	FROM Favorites f INNER JOIN Videos v
	ON f.VideoId = v.Id
	WHERE YEAR(f.LikeDate) = @year
	GROUP BY v.Title
END
GO