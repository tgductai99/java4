package poly.com.model;

import java.io.Serializable;

public class Employee implements Serializable
{
String manv;
String tennv;
boolean gt;
float luong;

public String getManv() {
	return manv;
}
public void setManv(String manv) {
	this.manv = manv;
}
public String getTennv() {
	return tennv;
}
public void setTennv(String tennv) {
	this.tennv = tennv;
}
public boolean isGt() {
	return gt;
}
public void setGt(boolean gt) {
	this.gt = gt;
}
public float getLuong() {
	return luong;
}
public void setLuong(float luong) {
	this.luong = luong;
}
public Employee(String manv, String tennv, boolean gt, float luong) {
	this.manv = manv;
	this.tennv = tennv;
	this.gt = gt;
	this.luong = luong;
}
public Employee() {
	
}


}
