package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class JsonServlet
 */
@WebServlet("/json-data")
public class JsonServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public JsonServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// 1. Cấu hình phản hồi là JSON và mã hóa UTF-8
		response.setContentType("application/json");
		response.setCharacterEncoding("UTF-8");

		// 2. Chuỗi JSON cần trả về
		String json = "{\"manv\": \"TeoNV\", \"hoTen\":\"Nguyễn Văn Tèo\", \"gioiTinh\": true, \"luong\": 950.5}";

		// 3. Gửi JSON về client
		response.getWriter().write(json);
	}

}
