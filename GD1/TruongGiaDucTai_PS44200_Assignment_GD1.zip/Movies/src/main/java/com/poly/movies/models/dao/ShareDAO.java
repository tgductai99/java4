package com.poly.movies.models.dao;

import com.poly.movies.models.entities.Share;

public interface ShareDAO extends CrudDAO<Share, String> {
	
}
