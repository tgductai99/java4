package com.poly.movies.models.dao;

import com.poly.movies.models.entities.User;

public interface UserDAO extends CrudDAO<User, String> {

}
