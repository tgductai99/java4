
USE master;


--DROP DATABASE PolyOE;

CREATE DATABASE PolyOE;


USE PolyOE;


CREATE TABLE Users(
    Id       NVARCHAR(20)  NOT NULL,
    Password NVARCHAR(50)  NOT NULL,
    Fullname NVARCHAR(50)  NOT NULL,
    Email    NVARCHAR(50)  NOT NULL,
    Admin    BIT           NOT NULL, 
    PRIMARY KEY(Id)
)


INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
('admin01', '123', N'Nguyễn Văn A', 'admin.a@poly.edu.vn', 1);

-- 2. Tài khoản người dùng thường (User 1)
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
('user02', '123', N'Trần Thị B', 'b.tran@poly.edu.vn', 0);

-- 3. Tài khoản người dùng thường (User 2)
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
('user03', '123', N'Lê Văn C', 'c.le@poly.edu.vn', 0);

-- Ví dụ bổ sung thêm user có email kết thúc bằng @fpt.edu.vn và không phải admin (cho Bài 3)
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
('user04', '123', N'Đỗ Văn D', 'd.do@fpt.edu.vn', 0),
('user05', '123', N'Hoàng Thị E', 'e.hoang@fpt.edu.vn', 0),
('user06', '123', N'Phan Văn F', 'f.phan@fpt.edu.vn', 0);

-- Bổ sung các user khác để đạt tổng số > 15 cho Bài 4
INSERT INTO Users (Id, Password, Fullname, Email, Admin) VALUES
('user07', '123', N'Nguyễn G', 'g.nguyen@test.com', 0),
('user08', '123', N'Trần H', 'h.tran@test.com', 1),
('user09', '123', N'Lê I', 'i.le@test.com', 0),
('user10', '123', N'Phạm K', 'k.pham@test.com', 0),
('user11', '123', N'Vũ L', 'l.vu@test.com', 1),
('user12', '123', N'Đinh M', 'm.dinh@test.com', 0),
('user13', '123', N'Bùi N', 'n.bui@test.com', 0),
('user14', '123', N'Tạ P', 'p.ta@test.com', 0),
('user15', '123', N'Cao Q', 'q.cao@test.com', 1),
('user16', '123', N'Lý R', 'r.ly@test.com', 0);


SELECT * FROM Users;
