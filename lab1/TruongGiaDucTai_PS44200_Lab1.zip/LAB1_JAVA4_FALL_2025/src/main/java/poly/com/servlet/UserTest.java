package poly.com.servlet;

import poly.com.servlet.UserManager;

public class UserTest {

	public static void main(String[] args)
	{
		UserManager manager = new UserManager();
		
		// --- Test BÀI 2: CRUD ---
		// Chạy thử CRUD (tạo, cập nhật, xóa user có ID là U01)
		// manager.create(); 
		// manager.update();
		// manager.findById("U01");
		// manager.deleteById("U01");
		
		manager.findAll(); // Hiển thị tất cả user sau khi test CRUD

		// --- Test BÀI 3: Truy vấn có điều kiện ---
		manager.findUserByEmailAndRole();

		// --- Test BÀI 4: Truy vấn phân trang ---
		// Yêu cầu: Trang thứ 3 (index 2) với kích thước 5 user/trang
		int pageNumber = 2; // Index của trang 3
		int pageSize = 5;
		manager.findUsersInPage(pageNumber, pageSize);
		
		// Đóng tài nguyên sau khi hoàn thành
		manager.close();
	}
}
