package poly.com.servlet;

import java.util.List;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import jakarta.persistence.TypedQuery;
import poly.com.model.User;

public class UserManager {
    EntityManagerFactory factory = Persistence.createEntityManagerFactory("PolyOE");
    EntityManager em = factory.createEntityManager();

    public void findAll() {
        System.out.println("--- Chạy findAll() ---");
        String jpql = "SELECT o FROM User o";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        List<User> list = query.getResultList();

        list.forEach(user -> {
            String fullname = user.getFullname();
            Boolean admin = user.getAdmin();
            System.out.println(fullname + ":" + admin);
        });
    }

    public void findById(String id) {
        System.out.println("--- Chạy findById(" + id + ") ---");
        User user = em.find(User.class, id);
        if (user != null) {
            String fullname = user.getFullname();
            Boolean admin = user.getAdmin();
            System.out.println(fullname + ":" + admin);
        } else {
            System.out.println("Không tìm thấy user với ID: " + id);
        }
    }

    public void create() {
        System.out.println("--- Chạy create() ---");
        User user = new User("U01", "123", "Tèo", "teo@gmail.com", false);
        try {
            em.getTransaction().begin();
            em.persist(user);
            em.getTransaction().commit();
            System.out.println("Tạo user U01 thành công.");
        } catch (Exception e) {
            em.getTransaction().rollback();
            System.out.println("Tạo user thất bại.");
        }
    }

    public void update() {
        System.out.println("--- Chạy update() ---");
        User user = em.find(User.class, "U01");
        if (user != null) {
            user.setFullname("Nguyễn Văn Tèo");
            user.setEmail("teonv@gmail.com");
            try {
                em.getTransaction().begin();
                em.merge(user);
                em.getTransaction().commit();
                System.out.println("Cập nhật user U01 thành công.");
            } catch (Exception e) {
                em.getTransaction().rollback();
                System.out.println("Cập nhật user thất bại.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Không tìm thấy user U01 để cập nhật.");
        }
    }

    public void deleteById(String id) {
        System.out.println("--- Chạy deleteById(" + id + ") ---");
        User user = em.find(User.class, id);
        if (user != null) {
            try {
                em.getTransaction().begin();
                em.remove(user);
                em.getTransaction().commit();
                System.out.println("Xóa user " + id + " thành công.");
            } catch (Exception e) {
                em.getTransaction().rollback();
                System.out.println("Xóa user thất bại.");
                e.printStackTrace();
            }
        } else {
            System.out.println("Không tìm thấy user " + id + " để xóa.");
        }
    }
    
    // Phương thức cho BÀI 3
    public void findUserByEmailAndRole() {
        System.out.println("\n--- BÀI 3: User có email *@fpt.edu.vn và không phải Admin ---");
        String jpql = "SELECT o FROM User o WHERE o.email LIKE :search AND o.admin = :role";
        TypedQuery<User> query = em.createQuery(jpql, User.class);
        
        query.setParameter("search", "%@fpt.edu.vn");
        query.setParameter("role", false);
        
        List<User> list = query.getResultList();
        
        if (list.isEmpty()) {
            System.out.println("Không tìm thấy user nào thỏa mãn điều kiện.");
            return;
        }
        list.forEach(user -> {
            System.out.println("Họ tên: " + user.getFullname() + " | Email: " + user.getEmail());
        });
    }

    // Phương thức cho BÀI 4
    public void findUsersInPage(int pageNumber, int pageSize) {
        System.out.println("\n--- BÀI 4: Truy vấn trang thứ 3 (Index 2) với 5 user/trang ---");
        String jpql = "SELECT o FROM User o ORDER BY o.id"; // Thêm ORDER BY để phân trang ổn định
        TypedQuery<User> query = em.createQuery(jpql, User.class);

        // Vị trí bắt đầu: Trang thứ 3 (pageNumber = 2) * Kích thước 5 = 10
        query.setFirstResult(pageNumber * pageSize); 
        query.setMaxResults(pageSize);
        
        List<User> list = query.getResultList();
        
        if (list.isEmpty()) {
            System.out.println("Không tìm thấy user nào ở trang này.");
            return;
        }
        
        System.out.println("Hiển thị users từ vị trí " + (pageNumber * pageSize) + " đến " + (pageNumber * pageSize + pageSize - 1) + ":");
        list.forEach(user -> {
            System.out.println("ID: " + user.getId() + " | Fullname: " + user.getFullname());
        });
    }

    // Phương thức đóng tài nguyên
    public void close() {
        if (em != null && em.isOpen()) {
            em.close();
        }
        if (factory != null && factory.isOpen()) {
            factory.close();
        }
    }
}