package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import poly.com.model.CartItem1;
import poly.com.model.Item;

@WebServlet("/bai4")
public class Giohangcontroller extends HttpServlet {

	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Giohangcontroller() {
		super();
		// TODO Auto-generated constructor stub
	}

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		HttpSession session = req.getSession();
		List<CartItem1> cartItems = (List<CartItem1>) session.getAttribute("cartItems");

		if (cartItems == null) {
			cartItems = new ArrayList<>();
		}

		List<Item> items = new ArrayList<>();
		items.add(new Item("Nokia 2020", "2.jpeg", 500, 0.1));
		items.add(new Item("Samsung Xyz", "2.webp", 700, 0.15));
		items.add(new Item("iPhone Xy", "3.webp", 900, 0.25));
		items.add(new Item("Sony Erricson", "4.webp", 55, 0.3));

		req.setAttribute("items", items);
		req.getRequestDispatcher("cart.jsp").forward(req, resp);
		
		
		
	}

}
