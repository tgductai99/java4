package poly.com.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import poly.com.model.CartItem1;
import poly.com.model.Item;

@WebServlet("/CartController")
public class CartController extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        HttpSession session = req.getSession();
        List<CartItem1> cartItems = (List<CartItem1>) session.getAttribute("cartItems");
        if (cartItems == null) {
            cartItems = new ArrayList<>();
        }

        // --- Danh sách sản phẩm mẫu ---
        List<Item> items = new ArrayList<>();
        items.add(new Item("Nokia 2020", "2.webp", 500, 0.1));
        items.add(new Item("Samsung Xyz", "3.webp", 700, 0.15));
        items.add(new Item("iPhone Xy", "4.webp", 900, 0.25));
        items.add(new Item("Sony Erricson", "5.webp", 550, 0.3));

        req.setAttribute("items", items);

        // --- Xử lý hành động ---
        String action = req.getParameter("action");
        String itemName = req.getParameter("itemName");

        if (action != null && itemName != null) {
            if ("add".equals(action)) {
                int quantity = Integer.parseInt(req.getParameter("quantity"));
                for (Item item : items) {
                    if (item.getName().equals(itemName)) {
                        boolean found = false;
                        for (CartItem1 cartItem : cartItems) {
                            if (cartItem.getItem().getName().equals(itemName)) {
                                cartItem.setQuantity(cartItem.getQuantity() + quantity);
                                found = true;
                                break;
                            }
                        }
                        if (!found) {
                            cartItems.add(new CartItem1(item, quantity));
                        }
                        break;
                    }
                }
            } else if ("remove".equals(action)) {
                cartItems.removeIf(c -> c.getItem().getName().equals(itemName));
            } else if ("update".equals(action)) {
                int quantity = Integer.parseInt(req.getParameter("quantity"));
                for (CartItem1 c : cartItems) {
                    if (c.getItem().getName().equals(itemName)) {
                        c.setQuantity(quantity);
                        break;
                    }
                }
            }
        }

        // --- Tính tổng tiền ---
        double totalPrice = 0;
        for (CartItem1 c : cartItems) {
            totalPrice += c.getTotalPrice();
        }

        session.setAttribute("cartItems", cartItems);
        req.setAttribute("totalPrice", totalPrice);

        // --- Hiển thị lại JSP ---
        req.getRequestDispatcher("cart.jsp").forward(req, resp);
    }
}
