package poly.com.controller;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * Servlet implementation class Bai2Controller
 */
@WebServlet({ "/bai2", "/chuvi", "/dientich", "/tinhhieu" })
public class Bai2Controller extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public Bai2Controller() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		request.getRequestDispatcher("bai2.jsp").forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String chon = request.getRequestURI();

		float a, b, cv, dt, hieu;

		a = Float.parseFloat(request.getParameter("canha"));
		b = Float.parseFloat(request.getParameter("canhb"));

		if (chon.contains("/chuvi")) {
			chuvi(request, response);
			return;
		} else if (chon.contains("/dientich")) {
			dt = a * b;
			request.setAttribute("dt", dt);
		} else

		{
			hieu = a - b;
			request.setAttribute("hieu", hieu);
		}

		Double canha = Double.parseDouble(request.getParameter("canha"));
		Double canhb = Double.parseDouble(request.getParameter("canhb"));
		request.setAttribute("canha", canha);
		request.setAttribute("canhb", canhb);

		request.getRequestDispatcher("bai2.jsp").forward(request, response);
	}

	protected void chuvi(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		float a, b, cv;
		a = Float.parseFloat(req.getParameter("canha"));
		b = Float.parseFloat(req.getParameter("canhb"));
		cv = (a + b) * 2;
		req.setAttribute("cv", cv);
		Double canha = Double.parseDouble(req.getParameter("canha"));
		Double canhb = Double.parseDouble(req.getParameter("canhb"));
		req.setAttribute("canha", canha);
		req.setAttribute("canhb", canhb);
		req.getRequestDispatcher("bai2.jsp").forward(req, resp);
	}

}
