var username = null;
var websocket = null;
// Context Root chính xác của bạn
var contextRoot = "Lab8_TruongGiaDucTai_PS44200"; 

function init() {
    // 1. Nhắc người dùng nhập username
    while (username === null || username.trim() === "") {
        username = prompt("Enter username");
    }
    
    // 2. Mở kết nối đến chat server JSON CHAT
    // Kết nối đến: ws://localhost:8080/Lab8_TruongGiaDucTai_PS44200/json/chat/{username}
    var url = 'ws://' + window.location.host + '/' + contextRoot + '/json/chat/' + username;
    websocket = new WebSocket(url);

    // Xử lý sự kiện chấp nhận kết nối từ server
    websocket.onopen = function(resp) {
        console.log("onopen", resp);
    }

    // Xử lý sự kiện nhận tin nhắn chat từ server
    websocket.onmessage = function(resp) {
        // Server gửi JSON String, Client Parse thành Object
        try {
            var msg = JSON.parse(resp.data);
            var output = document.getElementById('messages');
            
            switch (msg.type) {
                case 1: // Thông báo (Join/Leave)
                    var messageText = msg.sender + msg.text;
                    output.innerHTML = `${output.innerHTML}<p style="color: grey;">${messageText}</p>`;
                    break;
                case 2: // Tin nhắn chat
                    var messageText = `<b>${msg.sender}:</b> ${msg.text}`;
                    output.innerHTML = `${output.innerHTML}<p>${messageText}</p>`;
                    break;
                case 3: // Cập nhật danh sách user (Chatters)
                    var countElement = document.getElementById('client-count');
                    if (msg.userList) {
                        countElement.innerHTML = `Chatters (${msg.userList.length}): ${msg.userList.join(', ')}`;
                    } else {
                        countElement.innerHTML = `Chatters: 0`;
                    }
                    break;
            }

            // Cuộn xuống cuối
            output.scrollTop = output.scrollHeight; 
            console.log("onmessage", msg);
        } catch (e) {
            // Trường hợp lỗi JSON Parse (nên không xảy ra nếu Server gửi đúng)
            console.error("Error parsing message data:", e, resp.data);
        }
    }

    // Xử lý sự kiện lỗi từ server
    websocket.onerror = function(resp) {
        alert('An error occured, closing application');
        console.log("onerror", resp);
    }

    // Xử lý sự kiện đóng kết nối từ server
    websocket.onclose = function(resp) {
        alert(resp.reason || 'Goodbye');
        console.log("onclose", resp);
    }
}

// Gửi tin nhắn chat đến server
function send() {
    var input = document.getElementById("message");
    
    // Tạo đối tượng Message theo cấu trúc JSON
    var msg = {sender: username, text: input.value, type: 2};
    
    // Chuyển Object thành JSON String và gửi đi
    websocket.send(JSON.stringify(msg));
    
    // Xóa nội dung ô nhập
    input.value = '';
}