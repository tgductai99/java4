package poly.com.servlet;

import jakarta.websocket.*;
import jakarta.websocket.server.PathParam;
import jakarta.websocket.server.ServerEndpoint;
import poly.com.model.Message;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;
import java.io.IOException;

@ServerEndpoint(value = "/json/chat/{username}",
        encoders = {MessageEncoder.class}, 
        decoders = {MessageDecoder.class})
public class JsonChatServerEndpoint {

    private static Map<String, Session> users = Collections.synchronizedMap(new HashMap<>());
    
    private void broadcast(Message message) {
        users.forEach((username, session) -> {
            try {
                session.getBasicRemote().sendObject(message);
            } catch (Exception e) {
                 System.err.println("Error sending message to " + username + ": " + e.getMessage());
            }
        });
    }

    private void sendUserList() {
        String[] userArray = users.keySet().toArray(new String[0]);
        Message userListMessage = new Message(3, userArray); 
        this.broadcast(userListMessage);
    }
    
    @OnOpen
    public void onOpen(Session session, @PathParam("username") String username) {
        users.put(username, session); 
        
        Message joinMessage = new Message(1, username, " joined the chat!");
        this.broadcast(joinMessage);
        
        this.sendUserList(); 
    }

    @OnMessage
    public void onMessage(Message message, Session session) {
        this.broadcast(message);
    }

    @OnClose
    public void onClose(Session session, @PathParam("username") String username) {
        users.remove(username); 
        
        Message leftMessage = new Message(1, username, " left the chat!");
        this.broadcast(leftMessage);
        
        this.sendUserList(); 
    }

    @OnError
    public void onError(Session session, Throwable throwable) {
        System.err.println("Error on session " + session.getId() + ": " + throwable.getMessage());
        try {
            session.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
