package poly.com.servlet;

import jakarta.websocket.Encoder;
import jakarta.websocket.EndpointConfig;
import poly.com.model.Message;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MessageEncoder implements Encoder.Text<Message> {

    private static ObjectMapper mapper = new ObjectMapper();

    @Override
    public String encode(Message message) {
        try {
            return mapper.writeValueAsString(message);
        } catch (Exception e) {
            e.printStackTrace();
            return "{}";
        }
    }

    @Override
    public void init(EndpointConfig config) {}

    @Override
    public void destroy() {}
}