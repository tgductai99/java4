package poly.com.servlet;

import jakarta.websocket.Decoder;
import jakarta.websocket.EndpointConfig;
import poly.com.model.Message;

import com.fasterxml.jackson.databind.ObjectMapper;

public class MessageDecoder implements Decoder.Text<Message> {

    private static ObjectMapper mapper = new ObjectMapper();

    @Override
    public Message decode(String jsonMessage) {
        try {
            return mapper.readValue(jsonMessage, Message.class);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    @Override
    public boolean willDecode(String s) {
        return true;
    }

    @Override
    public void init(EndpointConfig config) {}

    @Override
    public void destroy() {}
}