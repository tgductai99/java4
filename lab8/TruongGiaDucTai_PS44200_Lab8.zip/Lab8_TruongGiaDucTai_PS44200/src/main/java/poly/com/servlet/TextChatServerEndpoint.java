package poly.com.servlet;

import jakarta.websocket.*;
import jakarta.websocket.server.ServerEndpoint;
import java.util.HashMap;
import java.util.Map;
import java.io.IOException;

@ServerEndpoint("/text/chat")
public class TextChatServerEndpoint {
    
    // Duy trì danh sách session của các client đang kết nối
     private static Map<String, Session> sessions = new HashMap<>();

     // Gửi message đến tất cả client đang kết nối [cite: 36-37]
    private void broadcast(String message) {
         sessions.forEach((id, session) -> {
            try {
                 session.getBasicRemote().sendText(message); 
            } catch (Exception e) {
                 // e.printStackTrace(); [cite: 59]
            }
        });
    }

    // 2. Xử lý sự kiện chấp nhận kết nối (@OnOpen)
    @OnOpen
     public void onOpen(Session session) {
         sessions.put(session.getId(), session);
        // Yêu cầu: Gửi thông điệp "Someone joined the chat!"  đến tất cả mọi người [cite: 20-21]
         this.broadcast("Someone joined the chat!");
    }

    // 3. Xử lý sự kiện nhận tin nhắn chat (@OnMessage)
    @OnMessage
     public void onMessage(String message, Session session) { 
        try {
             // Yêu cầu: Chuyển tiếp tin nhắn đó đến tất cả mọi người [cite: 23-24]
             // Gắn thêm Session ID để giống giao diện mẫu "6: Xin chào..." [cite: 11]
             this.broadcast(session.getId() + ": " + message); 
        } catch (Exception e) {
            // e.printStackTrace();
        }
    }

    // 4. Xử lý sự kiện đóng kết nối (@OnClose)
    @OnClose
     public void onClose(Session session) { 
         sessions.remove(session.getId());
        // Yêu cầu: Gửi thông điệp "Someone left the chat!"  đến tất cả mọi người [cite: 22]
         this.broadcast("Someone left the chat!"); 
    }

    // 5. Xử lý sự kiện gặp lỗi (@OnError)
    @OnError
     public void onError(Session session, Throwable throwable) {
        try {
             session.close(); 
        } catch (IOException e) {
            // e.printStackTrace();
        }
         // e.printStackTrace(); [cite: 83]
    }
}
