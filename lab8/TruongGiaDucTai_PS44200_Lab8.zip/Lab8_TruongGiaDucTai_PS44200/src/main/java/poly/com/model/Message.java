package poly.com.model;

import java.util.Arrays;

public class Message {

    private int type; // 1: Info, 2: Chat, 3: UserList
    private String sender;
    private String text;
    private String[] userList; 

    // Constructor không tham số (Bắt buộc cho Jackson)
    public Message() {
    }

    // Các Constructor khác...

    // Getters and Setters (Đảm bảo đầy đủ)
    public int getType() { return type; }
    public void setType(int type) { this.type = type; }
    public String getSender() { return sender; }
    public void setSender(String sender) { this.sender = sender; }
    public String getText() { return text; }
    public void setText(String text) { this.text = text; }
    public String[] getUserList() { return userList; }
    public void setUserList(String[] userList) { this.userList = userList; }

    // Constructor cho tin nhắn chat (type 2)
    public Message(String sender, String text) {
        this.type = 2;
        this.sender = sender;
        this.text = text;
    }
    
    // Constructor cho thông báo (type 1)
    public Message(int type, String sender, String text) {
        this.type = type;
        this.sender = sender;
        this.text = text;
    }

    // Constructor cho danh sách user (type 3)
    public Message(int type, String[] userList) {
        this.type = type;
        this.userList = userList;
    }
}